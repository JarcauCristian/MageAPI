import subprocess
import tempfile
import os
if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter


@data_exporter
def export_data(data, *args, **kwargs):
    """
    Exports data to some source.

    Args:
        data: The output from the upstream parent block
        args: The output from any additional upstream blocks (if applicable)

    Output (optional):
        Optionally return any object and it'll be logged and
        displayed when inspecting the block run.
    """
    genome = "fmr1" if kwargs.get("genome") is None else kwargs.get("genome")

    with tempfile.NamedTemporaryFile(mode='w', delete=False) as fp:
        fp.write(data)
        fp.close()

        bowtie_command = [
            "bowtie-build",
            fp.name,
            genome
        ]

        try:
            subprocess.run(bowtie_command, check=True)
            print("Alignment complete. Output saved to output.sam")
        except subprocess.CalledProcessError as e:
            print(f"Error running Bowtie: {e}")

